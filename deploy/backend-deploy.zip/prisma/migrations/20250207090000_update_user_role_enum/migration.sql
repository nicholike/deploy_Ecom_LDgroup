-- Expand enum to include legacy and new role values so data can be migrated safely
ALTER TABLE `users`
  MODIFY `role` ENUM('ADMIN', 'MANAGER', 'DISTRIBUTOR', 'CUSTOMER', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6') NOT NULL DEFAULT 'CUSTOMER';

-- Map legacy role values to the new hierarchy
UPDATE `users` SET `role` = 'F1' WHERE `role` = 'MANAGER';
UPDATE `users` SET `role` = 'F2' WHERE `role` = 'DISTRIBUTOR';
UPDATE `users` SET `role` = 'F6' WHERE `role` = 'CUSTOMER';

-- Finalize enum to the new allowed values and default
ALTER TABLE `users`
  MODIFY `role` ENUM('ADMIN', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6') NOT NULL DEFAULT 'F6';
